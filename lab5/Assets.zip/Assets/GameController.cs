using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    [Header("Public Props")]
    public GameObject basketPrefab;
    public int NumberOfBaskets=3;
    public float BasketYStart = -10f;
    public int basketDY = 3;

    // Start is called before the first frame update
    void Start()
    {
        //Generate the baskets
        for (int i = 0; i < NumberOfBaskets; i++)
        {
            GameObject goBasket = Instantiate(basketPrefab);
            Vector3 basketPos = Vector3.zero;
            basketPos.y = BasketYStart + i * basketDY;
            goBasket.transform.position = basketPos;

        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
