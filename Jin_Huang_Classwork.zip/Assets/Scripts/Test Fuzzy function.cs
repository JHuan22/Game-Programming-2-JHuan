using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestFuzzyfunction : MonoBehaviour
{
    public float[] xs;
    public float[] ys;
    public float[] ys_lsh;
    public float[] ys_rsh;
    public float[] ys_tri;
    public float[] ys_tra;

    public float a_lsh = 0.05f, b_lsh = 0.4f;
    public float a_rsh = 0.05f, b_rsh = 0.4f;
    public float a_tri = 0.05f, b_tri = 0.4f, c_tri = 0.08f;
    public float a_tra = 0.05f, b_tra = 0.4f, c_tra = 0.5f, d_tra = 0.8f;

    // Start is called before the first frame update
    void Start()
    {
        float dx = 0.05f;
        int n = System.Convert.ToInt32(1f / dx);
        xs = new float[n];
        ys = new float[n];
        ys_rsh = new float[n];
        ys_tri = new float[n];
        ys_tra = new float[n];
        ys_lsh = new float[n];

        print($"n={n}");

        for (int i = 0; i < n; i++)
        {
            xs[i] = i * dx;

            ys_lsh[i] = FuzzyLogicUtilities.LeftShoulder(xs[i], a_lsh, b_lsh);
            ys_rsh[i] = FuzzyLogicUtilities.RightShoulder(xs[i], a_rsh, b_rsh);
            ys_tri[i] = FuzzyLogicUtilities.Triangle(xs[i], a_tri, b_tri, c_tri);
            ys_tra[i] = FuzzyLogicUtilities.Trapezoid(xs[i], a_tra, b_tra, c_tra, d_tra);

            print($"LSH: x={xs[i]}, y={ys_lsh[i]}");
        }

        for (int i = 0; i < n; i++)
        {
            print($"RSH: x={xs[i]}, y={ys_rsh[i]}");
        }

        for (int i = 0; i < n; i++)
        {
            print($"TRI: x={xs[i]}, y={ys_tri[i]}");
        }

        for (int i = 0; i < n; i++)
        {
            print($"TRA: x={xs[i]}, y={ys_tra[i]}");
        }
    }

    // Update is called once per frame
    void Update()
    {

    }
}