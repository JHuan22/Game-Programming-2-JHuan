using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FuzzyLogicUtilities
{
  public static float LeftShoulder(float x, float a, float b)
  {
    float res = 0;

    if ((x < 0) || (x > 1))
    {
      throw new Exception("X should be 0<=x<=1");
    }

    if (!(0 <= a && a < b && b <= 1))
    {
      throw new Exception("Value should be 0<=a<=b<=1");
    }
    if (x <= a)
    {
      res = 1;
    }
    else if (x <= b)
    {
      res = (b - x) / (b - a);
    }
    return res;
  }

  public static float RightShoulder(float x, float a, float b)
  {
    float res = 0;

    if ((x < 0) || (x > 1))
    {
      throw new Exception("X should be 0<=x<=1");
    }


    if (!(0 <= a && a < b && b <= 1))
    {
      throw new Exception("Value should be 0<=a<=b<=1");
    }
    if (x <= a)
    {
      res = 0;
    }
    else if (x <= b)
    {
      res = (x - b) / (b - a);
    }
    else if (x > b)
    {
      res = 1;
    }

    return res;
  }

    public static float Triangle(float x, float a, float b, float c)
  {
    float res = 0;

    if ((x < 0) || (x > 1))
    {
      throw new Exception("X should be 0<=x<=1");
    }


    if (!(0 <= a && a < b && b <= 1))
    {
      throw new Exception("Value should be 0<=a<=b<=1");
    }

    if (x <= a)
    {
     res = 0;
    }
    if (x <= b)
    {
      res = (x - a) / (b - a);
    }
    if (x <= c)
    {
      res = (c - x) / (c - b);
    }
    return res;  
  }

      public static float Trapezoid(float x, float a, float b,  float c, float d)
  {
    float res = 0;

    if ((x < 0) || (x > 1))
    {
      throw new Exception("X should be 0<=x<=1");
    }
    if (!(0 <= a && a < b && b <= 1))
    {
      throw new Exception("Value should be 0<=a<=b<=1");
    }
    if (x <= a)
    {
      res = 0;
    }
    if (x <= b)
    {
      res = (x - a) / (b - a);
    }
    if (x <= c)
    {
      res = 1;
    }
    if (x <= d)
    {
      res = (d - x) / (d - c);
    }
    return res;

  }
}
